# sap_xssec
XS Advanced Container Security API for python

## XS Advanced Authentication Primer

Authentication for python applications in XS Advanced relies on a special usage of the OAuth 2.0 protocol, which is based on central authentication at the UAA server that then vouches for the authenticated user's identity via a so-called OAuth Access Token. The current implementation uses as access token a JSON web token (JWT), which is a signed text-based token following the JSON syntax.

Normally, your python application will consist of several parts, that appear as separate applications in your manifest file, e.g. one application part that is responsible for the HANA database content, one application part for your application logic written e.g. in python (this is the one that can make use of this XS Advanced Container Security API for python), and finally one application part that is responsible for the UI layer (this is the one that may make use of the application router functionality). The latter two applications (the application logic in python and the application router) should be bound to one and the same UAA service instance. This has the effect, that these two parts can use the same OAuth client credentials.

When your business users access your application UI with their browser, the application router redirects the browser to the UAA where your business users need to authenticate. After successful authentication, the UAA sends - again via the business user's browser - an OAuth authorization code back to the application router. Now the application router sends this authorization code directly (not via the browser) to the UAA to exchange it into an OAuth access token. If the access token is obtained successfully, the business user has logged on to the UI part of your application already. In order to enable your UI to pass this authentication on to the python application part, you need to ensure that the destination to your python application part is configured such that the access token is actually sent to the python part ("forwardAuthToken": true).

In order to authenticate this request, which arrives at the python backend, *sap_xssec* offers a mechanisms to validate the access token.

*sap_xssec* offers an offline validation of the access token, which requires no additional call to the UAA. The trust for this offline validation is created by binding the XS UAA service instance to your application. Inside the credentials section in the environment variable *VCAP_SERVICES*, the key for validation of tokens is included. By default, the offline validation check will only accept tokens intended for the same OAuth2 client in the same UAA identity zone. This makes sense and will cover the vast majority of use cases. However, if an application absolutely wants to consume token that were issued for either different OAuth2 clients or different identity zones, an Access Control List (ACL) entry for this can be specified in an environment variable named *SAP_JWT_TRUST_ACL*. The name of the OAuth client is sb-<xsappname from xs-security.json>
The content is a JSON String, containing an array of identity zones and OAuth2 clients. To trust any OAuth2 client and/or identity zones, an * can be used. For OP, identity zones are not used and value for the identity zone is uaa.

```JSON
SAP_JWT_TRUST_ACL: [ {"clientid":"<client-id of the OAuth2 client>","identityzone":"<identity zone>"},...]
```

If you want to enable another (foreign) application to use some of your application's scopes, you can add a ```granted-apps``` marker to your scope in the ```xs-security.json``` file (as in the following example). The value of the marker is a list of applications that is allowed to request a token with the denoted scope.

```JSON
{
  "xsappname"     : "sample-leave-request-app",
  "description"   : "This sample application demos leave requests",
  "scopes"        : [ { "name"                : "$XSAPPNAME.createLR",
                        "description"         : "create leave requests" },
                      { "name"                : "$XSAPPNAME.approveLR",
                        "description"         : "approve leave requests",
                        "granted-apps"        : ["MobileApprovals"] }
                    ],
  "attributes"    : [ { "name"                : "costcenter",
                        "description"         : "costcenter",
                        "valueType"           : "string"
                    } ],
  "role-templates": [ { "name"                : "employee",
                        "description"         : "Role for creating leave requests",
                        "scope-references"    : [ "$XSAPPNAME.createLR","JobScheduler.scheduleJobs" ],
                        "attribute-references": [ "costcenter"] },
                      { "name"                : "manager",
                        "description"         : "Role for creating and approving leave requests",
                        "scope-references"    : [ "$XSAPPNAME.createLR","$XSAPPNAME.approveLR","JobScheduler.scheduleJobs" ],
                        "attribute-references": [ "costcenter" ] }
                    ]
}
```

### Direct Usage with existing Access Token

For the usage of the XS Advanced Container Security API it is necessary to pass a JWT token. If you have such a token, you may use the API as follows. The examples below rely on users and credentials that you should substitute with the ones in your context.

The typical use case for calling this API lies from within a container when an HTTP request is received. In an authorization header (with keyword `bearer`) an access token is contained already. You can remove the prefix `bearer` and pass the remaining string (just as in the following example as `access_token`) to the API.

```python
from sap import xssec
from cfenv import AppEnv

env = AppEnv()
uaa_service = env.get_service(name='<uaa_service_name>').credentials

security_context = xssec.create_security_context(access_token, uaa_service)
```

**Note:** That the example above uses module [`cfenv`](https://pypi.python.org/pypi/cfenv) to retrieve the configuration of the uaa service instance.

The creation function `xssec.create_security_context` is to be used for an end-user token (e.g. for grant_type `password` or grant_type `authorization_code`) where user information is expected to be available within the token and thus within the security context.

`create_security_context` also accepts a token of grant_type `client_credentials`. This leads to the creation of a limited *SecurityContext* where certain functions are not available. For more details please consult the API description below.

## API Description

### `xssec.create_security_context(access_token, uaa_service)` **->** `SecurityContext`
This function creates the Security Context by validating the received access token against credentials put into the application's environment via the UAA service binding.

Usually, the received token must be intended for the current application. More clearly, the OAuth client id in the access token needs to be equal to the OAuth client id of the application (from the application's environment).

However, there are some use cases, when a "foreign" token could be accepted although it was not intended for the current application. If you want to enable other applications calling your application backend directly, you can specify in your xs-security.json file an access control list (ACL) entry and declare which OAuth client from which Identity Zone may call your backend.

* `access_token` - String containing the access token as received from UAA in the "authorization Bearer" HTTP header.
* `uaa_service` - Dictionary containing the uaa service instance. Mandatory elements - url, clientid, clientsecret and verificationkey.

### `SecurityContext.get_logon_name() -> {str}`

Returns the logon name. Not available for tokens of grant_type `client_credentials`.

### `SecurityContext.get_given_name() -> {str}`

Returns the given name. Not available for tokens of grant_type `client_credentials`.

### `SecurityContext.get_family_name() -> {str}`

Returns the family name. Not available for tokens of grant_type `client_credentials`.

### `SecurityContext.get_email() -> {str}`

Returns the email. Not available for tokens of grant_type `client_credentials`.

### `SecurityContext.check_local_scope(scope) -> {bool}`
Checks a scope that is published by the current application in the xs-security.json file.
Returns `True` if the scope is contained in the user's scopes, `False` otherwise.

* `scope` - The scope whose existence is checked against the available scopes of the current user. Here, no prefix is required.

### `SecurityContext.check_scope(scope) -> {bool}`
Checks a scope that is published by an application.
Returns `True` if the scope is contained in the user's scopes, `False` otherwise

* `scope` - The scope whose existence is checked against the available scopes of the current user.  Here, the prefix is required, thus the scope string is "globally unique".

### `SecurityContext.get_token(namespace, name) -> {str}`
Returns a token that can be used e.g. for contacting the HANA database. If the token, that the security context has been instantiated with, is a foreign token (meaning that the OAuth client contained in the token and the OAuth client of the current application do not match), `None` is returned instead of a token.

* `namespace` - Tokens can eventually be used in different contexts, e.g. to access the HANA database, to access another XS2-based service such as the Job Scheduler, or even to access other applications/containers. To differentiate between these use cases, the `namespace` is used. In `xssec.constants` we define supported namespaces (e.g. `SYSTEM`).
* `name` - The name is used to differentiate between tokens in a given namespace, e.g. `HDB` for HANA database or `JOBSCHEDULER` for the job scheduler. These names are also defined in `xssec.constants`.

### `SecurityContext.get_hdb_token(namespace, name) -> {str}`
Returns a token that can be used for contacting the HANA database. If the token, that the security context has been instantiated with, is a foreign token (meaning that the OAuth client contained in the token and the OAuth client of the current application do not match), `None` is returned instead of a token.

### `SecurityContext.request_token_for_client(serviceCredentials, scopes) -> {str}`
Returns a token with `grant_type=user_token` from another client. Prerequisite is that the requesting client has `grant_type=user_token` and that the current user token includes the scope `uaa.user`.
* `service_credentials` - The credentials of the UAA service as a dictionary. The attributes `clientid`, `clientsecret` and `url` are mandatory.
* `scopes` - String containing comma-separated list of requested scopes for the token, e.g. `app.scope1,app.scope2`. If *None*, all scopes are granted. Note that $XSAPPNAME is not supported as part of the scope names.

### `SecurityContext.has_attributes() -> {bool}`
Returns `True` if the token contains any xs user attributes, `False` otherwise.
Not available for tokens of grant_type `client_credentials`.

### `SecurityContext.get_attribute(name) -> {str}`
Returns the attribute exactly as it is contained in the access token. If no attribute with the given name is contained in the access token, `None` is returned. If the token, that the security context has been instantiated with, is a foreign token (meaning that the OAuth client contained in the token and the OAuth client of the current application do not match), `None` is returned regardless of whether the requested attribute is contained in the token or not.
Not available for tokens of grant_type `client_credentials`.
* `name` - The name of the attribute that is requested.

### `SecurityContext.get_additional_auth_attr(name) -> {str}`
Returns the additional authentication attribute exactly as it is contained in the access token. If no attribute with the given name is contained in the access token, `None` is returned. Note that additional authentication attributes are also returned in foreign mode (in contrast to getAttribute).
* `name` - The name of the additional authentication attribute that is requested.

### `SecurityContext.is_in_foreign_mode() -> {bool}`
Returns `True` if the token, that the security context has been instantiated with, is a foreign token that was not originally issued for the current application, `False` otherwise.

### `SecurityContext.get_subdomain() -> {str}`
Returns the subdomain that the access token has been issued for.

### `SecurityContext.get_clientid() -> {str}`
Returns the client id that the access token has been issued for.

### `SecurityContext.get_identity_zone() -> {str}`
Returns the identity zone that the access token has been issued for.

### `SecurityContext.get_expiration_date() -> {datetime.datetime}`
Returns the expiration date of the access token as `datetime.datetime` object.

### `SecurityContext.get_clone_service_instance_id() -> {str}`
Returns the service instance id of the clone if the XSUAA broker plan is used.

### `SecurityContext.get_grant_type() -> {str}`
Returns the grant type of the JWT token, e.g. `authorization_code`, `password`, `client_credentials` or `urn:ietf:params:oauth:grant-type:saml2-bearer`.

## CF Deployment 

The deployment of python code to cloudfoundry executes 'pip install'. The package sap_xssec vendor dependent package which means it is not available in public repositories. The solution for this is a deployment with a local vendor folder, see
https://docs.cloudfoundry.org/buildpacks/python/index.html#vendoring 

Your application should have a so called requirements.txt file. In this file you define your dependencies, e.g. sap_xssec (this package includes sap_py_jwt). So before a push to cf you create a local vendor folder and put all dependend binaries into this folder.

The push command uploads the complete local folder to CF and the python buildpack then installs the private packages from the vendor folder.



