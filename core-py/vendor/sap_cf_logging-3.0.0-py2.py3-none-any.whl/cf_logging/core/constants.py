""" Logging module constants """
REQUEST_KEY = 'request'
RESPONSE_KEY = 'response'
